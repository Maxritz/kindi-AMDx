# kindi-vk binaries (RX 580 / gfx803, Windows x64)

Prebuilt engine for the AMD Polaris / GCN Vulkan port. No Vulkan SDK or compiler needed
to run; you only need an AMD driver with Vulkan support.

## Contents

```
kindi_vk_decode.exe   the GPU engine (Vulkan compute), CLI and HTTP server
kindi_cpu.exe         CPU mirror, used to cross-check the 2B
shaders/*.comp.spv    61 compiled compute shaders, loaded at runtime
```

kindi_vk_decode.exe loads its shaders from a `shaders` folder relative to the working
directory, so run it from this folder or keep the folder layout intact.

## Run

```powershell
.\kindi_vk_decode.exe --model C:\x\Ternary-Bonsai-2-2B-PTQ1_0.gguf --prompt "The sky is blue because" --temp 0 -n 20
```

```powershell
.\kindi_vk_decode.exe --model C:\x\Ternary-Bonsai-2-27B-PQ2_0.gguf --ctx 4096 --prompt "The sky is blue because" --temp 0 -n 8
```

27B PTQ1_0 with the MTP head, speculative decode (token-identical output, 1.47x):

```powershell
.\kindi_vk_decode.exe --model C:\x\Ternary-Bonsai-2-27B-PTQ1_0-mtp-procreations.gguf `
    --ctx 2048 --native5 --prompt "The sky is blue because" --temp 0 --spec 20
```

## OpenAI-compatible API

```powershell
.\kindi_vk_decode.exe --model C:\x\Ternary-Bonsai-2-2B-PTQ1_0.gguf --serve --port 8080
```

Then point any OpenAI client at `http://127.0.0.1:8080/v1`:

```python
from openai import OpenAI
c = OpenAI(base_url="http://127.0.0.1:8080/v1", api_key="none")
r = c.chat.completions.create(
    model="Ternary-Bonsai-2-2B-PTQ1_0",
    messages=[{"role": "user", "content": "What is 2+2?"}],
    max_tokens=16, temperature=0,
    extra_body={"enable_thinking": False},
)
print(r.choices[0].message.content)
```

Endpoints: `POST /v1/chat/completions`, `POST /v1/completions` (both stream),
`GET /v1/models`, `GET /health`. Prompt reuse is on by default. See API.md.

## Expected output

```
2B    "The sky is blue because"  ->  " of the scattering of light"
27B   "The sky is blue because"  ->  " of Rayleigh scattering. This is a"
```

## Useful flags

| flag | meaning |
|---|---|
| `--model <path.gguf>` | GGUF file (required) |
| `--prompt`, `-n`, `--temp`, `--top-k` | generation |
| `--ctx N` | context length; clamped to what the card can hold |
| `--native5` | keep PTQ1_0 in its 28-byte/128-weight form, needed for the 27B |
| `--spec N` | speculative decode with the MTP head (27B MTP model), CLI and `--serve` |
| `--serve`, `--host`, `--port` | run the OpenAI-compatible API |
| `--no-prefix-cache` | disable prompt reuse in the server |
| `--selftest` | validate the batched GEMVs against the single-token path |
| `--trace` | per-component and per-shader performance table |
| `--trace-json FILE` | write a machine-readable baseline |
| `--trace-decode` | start the trace table at decode, so prefill is not mixed in |
| `--dump` | per-layer probe values |

Environment: `KINDI_CHUNK=N` sets the prefill width (1..4; the server defaults it to 4,
`KINDI_CHUNK=0` forces the serial reference path). `KINDI_DEVICE=N` or a name picks a
device.

## Performance (RX 580, 8 GB, model load excluded)

| Model | Prefill | Prefill KINDI_CHUNK=4 | Token gen | Token gen `--spec` |
|---|---|---|---|---|
| 2B PTQ1_0 | 39.3 tok/s | 69.0 tok/s | 32-34 tok/s | n/a |
| 27B PQ2_0 | 1.71 tok/s | 3.03 tok/s | 1.5 tok/s | n/a |
| 27B PTQ1_0 + MTP | 1.7 tok/s | 3.0 tok/s | 0.85 tok/s | 1.25 tok/s |

Speculative decode acceptance is workload dependent: 1.47x on prompts it drafts well,
1.15x at 54% acceptance, and it needs about 27% acceptance to break even.

## Notes

- Built with MSVC 14.44 and the Vulkan SDK 1.4.363.0, linked against vulkan-1.lib and
  ws2_32.lib.
- The GPU is selected by name (RX 580) rather than by enumeration index, so it still works
  on a machine with an integrated GPU or a second card.
- Source, build script and the full write-ups are in the parent portingwork/ folder.
